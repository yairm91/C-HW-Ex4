﻿namespace Ex04.Menus.Interfaces
{
    public interface IAction
    {
        void ReportAction(string i_NameOfAction);
    }
}
